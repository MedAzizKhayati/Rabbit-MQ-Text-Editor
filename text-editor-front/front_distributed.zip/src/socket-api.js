import clientSocket from 'socket.io-client';
//import genUsername from "unique-username-generator";
import axios from "axios";

export const API_URL = "http://localhost:5555";
const socket = clientSocket(`${API_URL}/text`);
export const username = "user"+Math.random() * 100_000;//genUsername.generateUsername();

axios.post(API_URL + "/api/register", { username })
    .then(res => console.log(res.data))
    .catch(err => console.log(err));

export const subscribe = (newCallback, section) => {
    socket.on(username, (result) => {
        result = JSON.parse(result);
        if (result.section === section)
            newCallback(result.content);
    });
}