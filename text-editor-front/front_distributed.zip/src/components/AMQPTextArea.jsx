import { useEffect, useState } from "react";
import axios from "axios";
import * as API from "../socket-api";

const AMQPTextArea = ({ defaultContent, section }) => {
    const [content, setContent] = useState(defaultContent);
    const [increment, setIncrement] = useState(0);
    
    useEffect(() =>{
        API.subscribe(onContentChange, section);
    },[])

    const onContentChange = (newContent) => {
        setContent(newContent);
    }

    const onTextChange = (event) => {
        let newContent = event.target.value;
        setContent(newContent);
        axios.post(`${API.API_URL}/api/text`, {
            section,
            content: newContent,
        })
        .then(() => console.log("Message sent"))
        .catch(err => console.error(err))
    }

    return (
        <>
            <span>This section has been updated {increment} times.</span>
            <textarea onChange={e => {setIncrement(increment + 1); onTextChange(e);}}  value={content}/>
        </>
    );
}

export default AMQPTextArea;