import AMQPTextArea from './AMQPTextArea';
import './home.css';

const Home = () => {
    return (
        <div className="home">
            <h1>Welcome To Rabbit MQ Text Editor!</h1>
            <AMQPTextArea defaultContent= "Hello there, this is the first section..." section="section1"/>
            <AMQPTextArea defaultContent= "Hello there, this is the second section..." section="section2"/>
        </div>
    );
}
export default Home;